package com.meritamerica.assignment5.models;
import java.util.ArrayList;
import java.util.List;
import javax.naming.NameNotFoundException;
import com.meritamerica.assignment5.BankAccount.BankAccount;
import com.meritamerica.assignment5.controller.AccountHolder;
import com.meritamerica.assignment5.controller.CDOffering;

public class MeritBank {
	private static List<AccountHolder> accountHolders = new ArrayList<>();
	private static List<CDOffering> cdOfferings = new ArrayList<>();
	private static long nextAccountNumber = 1;
	private static long nextAccountHolderNumber = 1;
	
	public static void addAccountHolder(AccountHolder holder) {
		accountHolders.add(holder);
		setNextAccountHolderNumber(getNextAccountHolderNumber() + 1);
	}
	public static List<AccountHolder> getAccountHolders() { return accountHolders; }
	
	public static List<CDOffering> getCDOfferings() throws NameNotFoundException {
		if(cdOfferings.size() == 0) {  }
		return cdOfferings; 
	} 	
	public static BankAccount getBankAccount(long id) throws NameNotFoundException {
		for(AccountHolder holder : accountHolders) {
			for(BankAccount checks : holder.getCheckingAccounts() ) {
				if(checks.getAccountNumber() == id) { return checks; }
			}
			for(BankAccount savings : holder.getSavingsAccounts() ) {
				if(savings.getAccountNumber() == id) { return savings; }
			}
			for(BankAccount cd : holder.getCdAccounts() ) {
				if(cd.getAccountNumber() == id) { return cd; }
			}
		}
		System.out.println("Invalid Account id");
		return null;
	}
	
	public static AccountHolder getAccountHolderByID(long id) {
		for(AccountHolder holder : accountHolders) {
			if(holder.getId() == id) { return holder; }
		}
		System.out.println("Invalid Account Holder");
		return null;
	}
	
	static CDOffering getBestCDOffering(double depositAmount) {
		if(cdOfferings.size() == 0) { return null; }
		double bestRate = 0;
		CDOffering best = null;
		for(CDOffering cdOffer : cdOfferings) {
			if(cdOffer.getInterestRate() > bestRate) {
				best = cdOffer;
				bestRate = cdOffer.getInterestRate();
			}
		}
		return best;
	}
	static CDOffering getSecondBestCDOffering(double depositAmount) {
		if(cdOfferings.size() <= 1) { return null; }
		
		CDOffering best = getBestCDOffering(depositAmount);
		CDOffering secondBest = null;
		double secondBestRate = 0;
		
		for(CDOffering cdOffer : cdOfferings) {
			if(cdOffer == best) { continue; }
			if(cdOffer.getInterestRate() > secondBestRate) {
				secondBest = cdOffer;
				secondBestRate = cdOffer.getInterestRate();
			}	
		}
		return secondBest;
	}
	
	public static void clearCDOfferings() {
		cdOfferings.clear();
	}
	
	public static void setCDOfferins(List<CDOffering> offers) {
		for(CDOffering cdOffer : offers) {
			cdOfferings.add(cdOffer);
		}
	}
	public static void setCDOfferings(CDOffering[] offers) {
		for(int i=0; i<offers.length; i++) {
			cdOfferings.add(offers[i]);
		}
	}
	public static void addCDOffering(CDOffering offers) {
		cdOfferings.add(offers);
	}
	
    static double totalAccountBalances() {
        double total = 0;
        for (AccountHolder holder : accountHolders) {
            if (holder == null) {
                break;
            }

            for (BankAccount account : holder.getCheckingAccounts()) {
                try {
                    total += account.getBalance();
                } catch (NullPointerException expected) {
                }
            }
            for (BankAccount account : holder.getSavingsAccounts()) {
                try {
                	total += account.getBalance();
                } catch (NullPointerException expected) {
                }
            }
            for (BankAccount account : holder.getCdAccounts()) {
                try {
                	total += account.getBalance();
                } catch (NullPointerException expected) {
                }
            }
        }
        return total;
    }
    public static long getNextAccountNumber(long id) {return nextAccountNumber; }
	
	public static void setNextAccountNumber(long accountNumber) { nextAccountNumber = accountNumber; }
	
	public static long getNextAccountHolderNumber() { return nextAccountHolderNumber; }
	
	public static void setNextAccountHolderNumber(long accountNumber) { nextAccountHolderNumber = accountNumber; }

	public static long getNextAccountNumber() {
		return 0;
	}
	
}

