package com.meritamerica.assignment5.controller;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import com.meritamerica.assignment5.BankAccount.BankAccount;
import com.meritamerica.assignment5.BankAccount.CDAccount;
import com.meritamerica.assignment5.BankAccount.CheckingAccount;
import com.meritamerica.assignment5.BankAccount.SavingsAccount;
import com.meritamerica.assignment5.Exceptions.ExceedsCombinedBalanceLimitException;
import com.meritamerica.assignment5.models.MeritBank;

@Entity
public class AccountHolder {
	@NotBlank(message= "First name cannot be null")
    private String firstName;
    private String middleName;
	@NotBlank(message= "Last name cannot be null")
    private String lastName;
	@NotBlank(message ="SSN cannot be null")
	@Size(min = 8, max = 16, message = "SSN must be between 8 and 16 characters long")
    private String socialSecurityNumber;
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    
    private List<BankAccount> checkingAccounts;
	private List<BankAccount> savingsAccounts;
    private List<BankAccount> cdAccounts;

    AccountHolder(String firstName, String middleName, String lastName, String socialSecurityNumber) {
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
        this.checkingAccounts = new ArrayList<>();
        this.savingsAccounts = new ArrayList<>();
        this.cdAccounts = new ArrayList<>();
        this.id = MeritBank.getNextAccountHolderNumber();

    }

    public boolean addCheckingAccount(CheckingAccount checkingAccount) throws ExceedsCombinedBalanceLimitException {
        if (getCheckingBalance() + getSavingsBalance() + checkingAccount.getBalance() >= 250000) {
            return false;
        }
        checkingAccounts.add(checkingAccount);
        return true;
    }
   	public boolean addSavingsAccount(SavingsAccount savingsAccount) throws ExceedsCombinedBalanceLimitException {
        if (getCheckingBalance() + getSavingsBalance() + savingsAccount.getBalance() >= 250000) {
            return false;
        }
        savingsAccounts.add(savingsAccount);
        return true;
    }

    public boolean addCDAccount(CDAccount cdAccount) {
        if (cdAccount == null) {
            System.out.println("Invalid.");
            return false;
        }
        cdAccounts.add(cdAccount);
        return true;
    }
      
    public double getCheckingBalance() {
       double total = 0;
       for (BankAccount checks : checkingAccounts) {
       	total += checks.getBalance();
       }
       return total;
    }
    
    public double getSavingsBalance() {
        double total = 0;
        for (BankAccount savings : savingsAccounts) {
            total += savings.getBalance();
        }
        return total;
    }

    public double getCDBalance() {
        double total = 0;
        for (BankAccount cd : cdAccounts) {
            total += cd.getBalance();
        }
        return total;
    }
    
    public double getCombinedBalance() {
        double total = 0;
        total += getCheckingBalance();
        total += getSavingsBalance();
        total += getCDBalance();
        return total;
    }
    public int compareTo(AccountHolder holder) {
        int myTotal = (int) getCombinedBalance();
        int holderTotal = (int) holder.getCombinedBalance();
        return myTotal - holderTotal;
    }
    public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}

	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<BankAccount> getCheckingAccounts() {
		return checkingAccounts;
	}

	public void setCheckingAccounts(List<BankAccount> checkingAccounts) {
		this.checkingAccounts = checkingAccounts;
	}

	public List<BankAccount> getSavingsAccounts() {
		return savingsAccounts;
	}

	public void setSavingsAccounts(List<BankAccount> savingsAccounts) {
		this.savingsAccounts = savingsAccounts;
	}

	public List<BankAccount> getCdAccounts() {
		return cdAccounts;
	}

	public void setCdAccounts(List<BankAccount> cdAccounts) {
		this.cdAccounts = cdAccounts;
	}

}

