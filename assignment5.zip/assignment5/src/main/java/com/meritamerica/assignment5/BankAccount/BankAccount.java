package com.meritamerica.assignment5.BankAccount;
import java.util.Date;
import com.meritamerica.assignment5.Exceptions.ExceedsAvaliableBalanceException;
import com.meritamerica.assignment5.Exceptions.ExceedsFraudSuspicionLimitException;
import com.meritamerica.assignment5.Exceptions.NegativeAmountException;
import com.meritamerica.assignment5.models.MeritBank;

public abstract class BankAccount {
	
	private double balance;
    private double interestRate;
    private long accountNumber;
    private Date openedOn;
    
    BankAccount(double balance, double interestRate) {
        this.balance = balance;
        this.interestRate = interestRate;
        this.openedOn = new Date();
        this.accountNumber = MeritBank.getNextAccountNumber();
		MeritBank.setNextAccountNumber(MeritBank.getNextAccountNumber() + 1); 
    }
    BankAccount(double balance, double interestRate, Date openedOn, long accountNumber) {
        this.balance = balance;
        this.interestRate = interestRate;
        this.openedOn = openedOn;
        this.accountNumber = accountNumber;
    }
    public BankAccount() {
		this.openedOn = new Date();
		this.accountNumber = MeritBank.getNextAccountNumber();
		MeritBank.setNextAccountNumber(MeritBank.getNextAccountNumber() + 1); 
	}
    public boolean withdraw(double amount) throws ExceedsAvaliableBalanceException, NegativeAmountException {

        if ((amount > this.balance) || (amount < 0)) {
            System.out.println("Invalid entry");
            return false;
        }
        this.balance = this.balance - amount;
        return true;

    }

    public boolean deposit(double amount) throws ExceedsFraudSuspicionLimitException, NegativeAmountException {
        if (amount < 0) {
            System.out.println("Please deposit a valid amount");
            return false;
        }
        if (amount > 1000) {
        	System.out.println("Daily deposit cannot exceed $1000, Please enter a valid amount");
        	return false;
        }
        this.balance = this.balance + amount;
        return true;
    }

    public double futureValue(int years)  { 
        if (years < 1) {
            System.out.println("Invalid, minimum 1 year!");
        }
        return futureValue(years -1) * (1 + this.interestRate);
    }

	public double getBalance() { return balance; }
	public double getInterestRate() { return interestRate; }
	public long getAccountNumber() { return accountNumber; }
	public Date getOpenedOn() { return openedOn; }
	public void setBalance(double balance) { this.balance = balance; }
	public void setInterestRate(double interestRate) { this.interestRate = interestRate; }
	public void setAccountNumber(long accountNumber) { this.accountNumber = accountNumber; }
	public void setAccountOpenedOn(Date opnedOn) { this.openedOn = opnedOn; }

}
	
