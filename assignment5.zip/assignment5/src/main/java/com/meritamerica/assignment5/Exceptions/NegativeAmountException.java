package com.meritamerica.assignment5.Exceptions;

public class NegativeAmountException extends Exception {
	private static final long serialVersionUID = 2445082265779255734L;

}
