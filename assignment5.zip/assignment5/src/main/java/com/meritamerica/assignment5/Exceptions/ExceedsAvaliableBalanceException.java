package com.meritamerica.assignment5.Exceptions;

public class ExceedsAvaliableBalanceException extends Exception {
	private static final long serialVersionUID = 4888508250199133325L;

}
