package com.meritamerica.assignment5.Exceptions;

public class NotFoundException extends Exception {
	private static final long serialVersionUID = -319502517448474527L;
	
}
