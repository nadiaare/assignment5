package com.meritamerica.assignment5.controller;

public class CDOffering {

    private int term;
    private double interestRate;

    public CDOffering(int term, double interestRate, double amount) {
        this.term = term;
        this.interestRate = interestRate;
    }
    public double getInterestRate(CDOffering offering, double balance) {
		return interestRate;
	}
    public CDOffering() {
    } 
    public boolean withdraw(double amount) {
        if (amount >= 0 && amount < 0) {
            System.out.println("You cannot withdraw from a CD Account!");
        }
        return false;
    }
    public int getTerm() {
        if (term == 1) {
            return 1;
        }
        if (term == 2) {
            return 2;
        }
        if (term == 3) {
            return 3;
        }
        if (term == 5) {
            return 5;
        }
        if (term == 10) {
            return 10;
        }
        else {
            System.out.println("Invalid term");
        }
        return this.term;
    }
	public double getInterestRate() {
		        if (term == 1) {
		            return Math.pow(1 + 0.019, (term));
		        }
		        if (term == 2) {
		            return Math.pow(1 + 0.02, term);
		        }
		        if (term == 5) {
		            return Math.pow(1 + 0.025, term);
		        }
		        if (term == 10) {
		            return Math.pow(1 + .035, term);
		        }
		        return this.interestRate;  
	}
}


