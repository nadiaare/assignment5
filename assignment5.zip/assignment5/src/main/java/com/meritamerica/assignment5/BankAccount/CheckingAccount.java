package com.meritamerica.assignment5.BankAccount;

import java.util.Date;

public class CheckingAccount extends BankAccount {

    static final double INTEREST_RATE = .0001;

    public CheckingAccount(double openingBalance) {
        super(openingBalance, INTEREST_RATE);
    }
    public CheckingAccount(double balance, double interestRate, Date openedOn, long accountNumber) {
        super(balance, interestRate, openedOn, accountNumber);
    }
    public CheckingAccount(BankAccount checkingAccount) {
        super(((BankAccount) checkingAccount).getBalance(), checkingAccount.getInterestRate(), checkingAccount.getOpenedOn(), checkingAccount.getAccountNumber());
    }
    public CheckingAccount() {
    	super();
    	super.setInterestRate(INTEREST_RATE);
    }

}