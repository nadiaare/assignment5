package com.meritamerica.assignment5.controller;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.meritamerica.assignment5.BankAccount.BankAccount;
import com.meritamerica.assignment5.BankAccount.CDAccount;
import com.meritamerica.assignment5.BankAccount.CheckingAccount;
import com.meritamerica.assignment5.BankAccount.SavingsAccount;
import com.meritamerica.assignment5.Exceptions.ExceedsCombinedBalanceLimitException;
import com.meritamerica.assignment5.Exceptions.NoSuchResourceFoundException;
import com.meritamerica.assignment5.Exceptions.NotFoundException;
import com.meritamerica.assignment5.models.MeritBank;

@RestController
public class MeritBankController {	
	
	@PostMapping("/AccountHolders")
	//@ResponseStatus(HttpStatus.CREATED)
	public AccountHolder addAccountHolder(@RequestBody @Valid AccountHolder holder) {
		MeritBank.addAccountHolder(holder);
		return holder;
	}
	@GetMapping(value = "/AccountHolders")
	public List<AccountHolder> getAccountHolder() {
		return MeritBank.getAccountHolders();
	}
	
	@GetMapping(value = "/AccountHolders/{id}")
	public AccountHolder getAccountHolderById(@PathVariable (name = "id") long id) throws NotFoundException {
		AccountHolder holder = MeritBank.getAccountHolderByID(id);
		return holder;
	}
	@PostMapping("/AccountHolders/{id}/CheckingAccounts")
	//@ResponseStatus(HttpStatus.CREATED)
	public CheckingAccount addCheckingAccount(@PathVariable(name = "id") long id, @RequestBody @Valid CheckingAccount check)
			throws NotFoundException, ExceedsCombinedBalanceLimitException {
		//AccountHolder holder = MeritBank.getNextAccountNumber(id);
		AccountHolder holder = MeritBank.getAccountHolderByID(id);
		return check;
	}
	@GetMapping("/AccountHolders/{id}/CheckingAccounts")
	public List<BankAccount> getCheckingAccounts(@PathVariable(name = "id") long id) throws NotFoundException {
		AccountHolder holder = MeritBank.getAccountHolderByID(id);
		return holder.getCheckingAccounts();
	}
	@PostMapping("/AccountHolders/{id}/SavingsAccounts")
	//@ResponseStatus(HttpStatus.CREATED)
	public SavingsAccount addSavingsAccount(@PathVariable (name = "id") long id, @RequestBody @Valid SavingsAccount savingsAccount) 
			throws NotFoundException, ExceedsCombinedBalanceLimitException {
				AccountHolder holder = MeritBank.getAccountHolderByID(id);
				holder.addSavingsAccount(savingsAccount);
				return savingsAccount;
			}

	@GetMapping("/AccountHolders/{id}/SavingsAccounts")
	public List<BankAccount> getSavingsAccounts(@PathVariable(name = "id") long id) throws NotFoundException {
		AccountHolder holder = MeritBank.getAccountHolderByID(id);
		return holder.getSavingsAccounts();
	}
	
	@PostMapping("/AccountHolders/{id}/CDAccounts")
	//@ResponseStatus(HttpStatus.CREATED)
	public CDAccount addCDAccount(@PathVariable (name = "id") long id, @RequestBody @Valid CDAccount cdAccount) 
			throws NotFoundException, ExceedsCombinedBalanceLimitException {
				AccountHolder holder = MeritBank.getAccountHolderByID(id);
				holder.addCDAccount(cdAccount);
				return cdAccount;
	}
	
	@GetMapping("/AccountHolders/{id}/CDAccounts")
	public List<BankAccount> getCDAccounts(@PathVariable(name = "id") long id) throws NotFoundException {
		AccountHolder holder = MeritBank.getAccountHolderByID(id);
		return holder.getSavingsAccounts();
	}
}