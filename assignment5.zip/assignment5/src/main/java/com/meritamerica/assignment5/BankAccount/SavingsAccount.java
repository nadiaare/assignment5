package com.meritamerica.assignment5.BankAccount;

import java.util.Date;

public class SavingsAccount extends BankAccount{

    static final double INTEREST_RATE =.01;

    public SavingsAccount(double openingBalance) {
        super(openingBalance, INTEREST_RATE);
    }
    public SavingsAccount(double balance, double interestRate, Date OpenDate, long accountNumber) {
        super(balance, interestRate, OpenDate, accountNumber);
    }
    public SavingsAccount(BankAccount savingsAccount) {
        super(savingsAccount.getBalance(), savingsAccount.getInterestRate(), savingsAccount.getOpenedOn(), savingsAccount.getAccountNumber());
    }
    public SavingsAccount() {
    	super();
    	super.setInterestRate(INTEREST_RATE);
    }
    
 }

