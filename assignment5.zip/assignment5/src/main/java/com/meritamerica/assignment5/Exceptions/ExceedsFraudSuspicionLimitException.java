package com.meritamerica.assignment5.Exceptions;

public class ExceedsFraudSuspicionLimitException extends Exception {
	private static final long serialVersionUID = 1028973172172691879L;

}
