package com.meritamerica.assignment5.Exceptions;

public class NoSuchResourceFoundException extends Exception {
	private static final long serialVersionUID = -8111249283919698879L;

}
