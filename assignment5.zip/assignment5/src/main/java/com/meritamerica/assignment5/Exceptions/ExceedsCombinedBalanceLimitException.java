package com.meritamerica.assignment5.Exceptions;

public class ExceedsCombinedBalanceLimitException extends Exception {
	private static final long serialVersionUID = 1L;

}
