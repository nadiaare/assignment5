package com.meritamerica.assignment5.BankAccount;
import java.util.Date;

import com.meritamerica.assignment5.Exceptions.ExceedsFraudSuspicionLimitException;
import com.meritamerica.assignment5.Exceptions.NegativeAmountException;
import com.meritamerica.assignment5.controller.CDOffering;
import com.meritamerica.assignment5.models.MeritBank;

public class CDAccount extends BankAccount{

    private int term;
    private Date opnedOn;

    public CDAccount(double balance, double interestRate, int term) {
        super(balance, interestRate);
        this.term = term;
    }
    public CDAccount(double balance, double interestRate, int term, long accountNumber) {
        super(balance, interestRate, new Date(), accountNumber);
        this.term = term;
    }
    public CDAccount(double balance, double interestRate, Date openedOn, long accountNumber, int term) {
        super(balance, interestRate, openedOn, accountNumber);
        this.term = term;
    }
	public boolean withdraw(double amount) {
        if (amount >= 0 && amount < 0) {
            System.out.println("You cannot withdraw from a CD Account!");
        }
        return false;
    }
    public boolean deposit(double amount) throws NegativeAmountException {
        throw new NegativeAmountException();
    }
    public int getTerm() {
        return this.term;
    }
    public Date getOpenOn() {
        return opnedOn;
    }
}